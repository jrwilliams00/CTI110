user_name = input()
print('welcome', user_name)

''' Type your code here. '''