# Making A Budget Expense
# 21 Sept 22
# CTI - 110 P1HW2 Travel Expense
# Williams Jeff



# user enter buget
# user enter travel
# user enter gas
# user enter accomodation
# user enter food
# add expense
# subtract expense from budget
# Display results



# Input
budget = int(input('Enter your budget:'))
travel = (input('Enter your Destination:'))
gas = int(input('How much did you spend on Gas?'))
accomodation = int(input('How much did you spend on Accomodation >'))
food = int(input('How much did you spend on Food '))


# Process
expense =  gas + accomodation + food
remains = budget - expense


# Output
print('__________Travel Expenses__________')
print('Location:' ,travel)
print('Initial Budget:' ,budget)
print()
print('Fuel:' ,gas)
print('Accomodation:' ,accomodation)
print('Food:' ,food)
print()
print('Remaining Balance:', remains)
      

